// Background service worker for Phishing Shield extension
const API_ENDPOINT = 'http://localhost:5000/analyze';

// Process and analyze the current URL when a page loads
chrome.webNavigation.onCompleted.addListener(async (details) => {
  if (details.frameId === 0) { // Only analyze main frame, not iframes
    await analyzeCurrentUrl(details.tabId, details.url);
  }
});

// Analyze the URL of the current tab
async function analyzeCurrentUrl(tabId, url) {
  try {
    // Skip extension pages, local files, etc.
    if (!url.startsWith('http')) {
      return;
    }
    
    console.log(`Analyzing URL: ${url}`);
    
    // Call API to analyze URL
    const response = await fetch(API_ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ url: url })
    });
    
    if (!response.ok) {
      throw new Error(`API error: ${response.status}`);
    }
    
    const result = await response.json();
    console.log('Analysis result:', result);
    
    // Store the result in local storage for this tab
    chrome.storage.local.set({ [`tab_${tabId}`]: result });
    
    // Send the result to the content script to display the overlay
    chrome.tabs.sendMessage(tabId, {
      action: 'showPhishingAlert',
      data: result
    });
    
    // Update the extension icon based on the result
    updateExtensionIcon(tabId, result.prediction === 1);
    
  } catch (error) {
    console.error('Error analyzing URL:', error);
  }
}

// Update the extension icon based on analysis result
function updateExtensionIcon(tabId, isLegitimate) {
  const iconPath = isLegitimate ? 
    {
      16: "icons/safe16.png",
      48: "icons/safe48.png",
      128: "icons/safe128.png"
    } : 
    {
      16: "icons/danger16.png", 
      48: "icons/danger48.png",
      128: "icons/danger128.png"
    };
  
  chrome.action.setIcon({
    tabId: tabId,
    path: iconPath
  });
}

// Listen for commands from the popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'getAnalysisResult') {
    chrome.tabs.query({active: true, currentWindow: true}, async (tabs) => {
      if (tabs.length > 0) {
        const tabId = tabs[0].id;
        const data = await chrome.storage.local.get(`tab_${tabId}`);
        sendResponse(data[`tab_${tabId}`] || null);
      } else {
        sendResponse(null);
      }
    });
    return true; // Required for async sendResponse
  }
  
  // Manual scan request from popup
  if (message.action === 'scanCurrentPage') {
    chrome.tabs.query({active: true, currentWindow: true}, async (tabs) => {
      if (tabs.length > 0) {
        await analyzeCurrentUrl(tabs[0].id, tabs[0].url);
        sendResponse({success: true});
      }
    });
    return true; // Required for async sendResponse
  }
});