document.addEventListener("DOMContentLoaded", async function() {
    const scanButton = document.getElementById("scanButton");
    
    // Function to perform URL analysis
    function analyzeCurrentUrl() {
        // Get active tab URL
        chrome.tabs.query({ active: true, currentWindow: true }, async function(tabs) {
            let url = tabs[0].url;
            let statusElement = document.getElementById("status");
            let resultElement = document.getElementById("result");

            statusElement.innerText = "Analyzing website...";

            try {
                // First check if there's already a cached result
                const tabId = tabs[0].id;
                const cachedData = await chrome.storage.local.get(`tab_${tabId}`);
                let data;
                
                if (cachedData[`tab_${tabId}`]) {
                    // Use cached result
                    data = cachedData[`tab_${tabId}`];
                    statusElement.innerText = "Using cached analysis";
                } else {
                    // Send the URL to your backend for analysis
                    const response = await fetch("http://127.0.0.1:5000/analyze", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ url: url })
                    });
                    
                    if (!response.ok) {
                        throw new Error(`API error: ${response.status}`);
                    }
                    
                    data = await response.json();
                    statusElement.innerText = "Analysis Complete";
                }
                
                // Get prediction results
                let label = data.prediction === 1 ? "Legitimate" : "Phishing";
                let confidence = data.prediction === 1 ? 
                    data.legitimate_probability : data.phishing_probability;
                let legitimateProb = data.legitimate_probability;

                // Display results
                resultElement.innerHTML = `
                    <p><strong>Status:</strong> ${label}</p>
                    <p><strong>Confidence:</strong> ${(confidence * 100).toFixed(1)}%</p>
                    <p><strong>Legitimate Probability:</strong> ${(legitimateProb * 100).toFixed(1)}%</p>
                `;

                // Style based on result
                resultElement.className = data.prediction === 1 ? "safe" : "phishing";
                
            } catch (error) {
                console.error("Error:", error);
                statusElement.innerText = "Error in fetching data!";
                resultElement.innerHTML = `<p>Error: ${error.message}</p>`;
                resultElement.className = "";
            }
        });
    }
    
    // Analyze URL when popup opens
    analyzeCurrentUrl();
    
    // Handle scan button click
    scanButton.addEventListener("click", function() {
        // Request a new scan from the background script
        chrome.runtime.sendMessage({action: "scanCurrentPage"}, function(response) {
            if (response && response.success) {
                // Wait a moment for the scan to complete, then refresh the popup data
                setTimeout(analyzeCurrentUrl, 500);
            }
        });
    });
});