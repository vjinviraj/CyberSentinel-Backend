// Content script that runs in the context of web pages

let overlayElement = null;
const OVERLAY_DISPLAY_TIME = 10000; // 10 seconds

// Listen for messages from the background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'showPhishingAlert') {
    showPhishingOverlay(message.data);
  }
});

// Create and show the phishing alert overlay
function showPhishingOverlay(result) {
  // Remove any existing overlay
  removeOverlay();
  
  // Create overlay container
  overlayElement = document.createElement('div');
  overlayElement.id = 'phishing-shield-overlay';
  overlayElement.className = 'phishing-shield-overlay';
  
  // Determine color scheme based on prediction
  const isLegitimate = result.prediction === 1;
  const colorClass = isLegitimate ? 'legitimate' : 'phishing';
  overlayElement.classList.add(colorClass);
  
  // Create content for the overlay
  const overlayContent = document.createElement('div');
  overlayContent.className = 'overlay-content';
  
  // Create header with result
  const header = document.createElement('div');
  header.className = 'result-header';
  
  const statusIcon = document.createElement('span');
  statusIcon.className = 'status-icon';
  statusIcon.textContent = isLegitimate ? '✓' : '⚠️';
  
  const statusText = document.createElement('h2');
  statusText.textContent = isLegitimate ? 'Legitimate Website' : 'Potential Phishing Detected!';
  
  header.appendChild(statusIcon);
  header.appendChild(statusText);
  
  // Create confidence meter
  const confidenceWrapper = document.createElement('div');
  confidenceWrapper.className = 'confidence-wrapper';
  
  const confidenceMeter = document.createElement('div');
  confidenceMeter.className = 'confidence-meter';
  
  const confidenceFill = document.createElement('div');
  confidenceFill.className = 'confidence-fill';
  const relevantConfidence = isLegitimate ? 
    result.legitimate_probability * 100 : 
    result.phishing_probability * 100;
  confidenceFill.style.width = `${relevantConfidence}%`;
  
  const confidenceLabel = document.createElement('div');
  confidenceLabel.className = 'confidence-label';
  confidenceLabel.textContent = `Confidence: ${relevantConfidence.toFixed(1)}%`;
  
  confidenceMeter.appendChild(confidenceFill);
  confidenceWrapper.appendChild(confidenceMeter);
  confidenceWrapper.appendChild(confidenceLabel);
  
  // Create close button
  const closeButton = document.createElement('button');
  closeButton.className = 'close-button';
  closeButton.textContent = '×';
  closeButton.addEventListener('click', removeOverlay);
  
  // Assemble overlay
  overlayContent.appendChild(header);
  overlayContent.appendChild(confidenceWrapper);
  overlayElement.appendChild(overlayContent);
  overlayElement.appendChild(closeButton);
  
  // Add overlay to page
  document.body.appendChild(overlayElement);
  
  // Automatically hide after a delay if it's legitimate
  if (isLegitimate) {
    setTimeout(removeOverlay, OVERLAY_DISPLAY_TIME);
  }
}

// Remove the overlay from the page
function removeOverlay() {
  if (overlayElement && overlayElement.parentNode) {
    overlayElement.parentNode.removeChild(overlayElement);
    overlayElement = null;
  }
}

// Initialize and check if there's already an analysis result for this page
chrome.runtime.sendMessage({action: 'getAnalysisResult'}, (result) => {
  if (result) {
    showPhishingOverlay(result);
  }
});